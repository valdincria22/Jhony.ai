/**
 * Image generation helper using internal ImageService
 *
 * Example usage:
 *   const { url: imageUrl } = await generateImage({
 *     prompt: "A serene landscape with mountains"
 *   });
 *
 * For editing:
 *   const { url: imageUrl } = await generateImage({
 *     prompt: "Add a rainbow to this landscape",
 *     originalImages: [{
 *       url: "https://example.com/original.jpg",
 *       mimeType: "image/jpeg"
 *     }]
 *   });
 */
import { storagePut } from "../storage";
import { ENV } from "./env";

export type GenerateImageOptions = {
  prompt: string;
  originalImages?: Array<{
    url?: string;
    b64Json?: string;
    mimeType?: string;
  }>;
};

export type GenerateImageResponse = {
  url?: string;
};

export async function generateImage(
  options: GenerateImageOptions
): Promise<GenerateImageResponse> {
  if (!ENV.forgeApiUrl) {
    throw new Error("BUILT_IN_FORGE_API_URL is not configured");
  }
  if (!ENV.forgeApiKey) {
    throw new Error("BUILT_IN_FORGE_API_KEY is not configured");
  }

  // Build the full URL by appending the service path to the base URL
  const baseUrl = ENV.forgeApiUrl.endsWith("/")
    ? ENV.forgeApiUrl
    : `${ENV.forgeApiUrl}/`;
  const fullUrl = new URL(
    "images.v1.ImageService/GenerateImage",
    baseUrl
  ).toString();

  const response = await fetch(fullUrl, {
    method: "POST",
    headers: {
      accept: "application/json",
      "content-type": "application/json",
      "connect-protocol-version": "1",
      authorization: `Bearer ${ENV.forgeApiKey}`,
    },
    body: JSON.stringify({
      prompt: options.prompt,
      original_images: options.originalImages || [],
    }),
  });

  if (!response.ok) {
    const detail = await response.text().catch(() => "");
    throw new Error(
      `Image generation request failed (${response.status} ${response.statusText})${detail ? `: ${detail}` : ""}`
    );
  }

  let result: any;
  try {
    result = await response.json();
  } catch (e) {
    const text = await response.text();
    console.error("[imageGeneration] Failed to parse JSON response:", text);
    throw new Error(`Failed to parse image generation response: ${text}`);
  }

  // Log para debug
  console.log("[imageGeneration] Response structure:", JSON.stringify(result).substring(0, 200));

  // Extrair base64 com tolerância a variações
  let base64Data: string | undefined;
  let mimeType = "image/png"; // default

  // Tentar diferentes formatos de resposta
  if (result.image?.b64Json) {
    base64Data = result.image.b64Json;
    mimeType = result.image.mimeType || "image/png";
  } else if (result.image?.b64_json) {
    base64Data = result.image.b64_json;
    mimeType = result.image.mime_type || "image/png";
  } else if (result.images && Array.isArray(result.images) && result.images.length > 0) {
    const firstImage = result.images[0];
    base64Data = firstImage.b64Json || firstImage.b64_json;
    mimeType = firstImage.mimeType || firstImage.mime_type || "image/png";
  } else if (result.b64Json) {
    // Resposta direta sem wrapper
    base64Data = result.b64Json;
    mimeType = result.mimeType || "image/png";
  } else if (result.b64_json) {
    // Resposta direta em snake_case
    base64Data = result.b64_json;
    mimeType = result.mime_type || "image/png";
  }

  if (!base64Data) {
    console.error("[imageGeneration] No base64 data found in response:", JSON.stringify(result));
    throw new Error(
      `Image generation response missing base64 data. Response: ${JSON.stringify(result).substring(0, 500)}`
    );
  }

  // Converter base64 para buffer
  let buffer: Buffer;
  try {
    buffer = Buffer.from(base64Data, "base64");
  } catch (e) {
    console.error("[imageGeneration] Failed to decode base64:", e);
    throw new Error(`Failed to decode base64 image data: ${String(e)}`);
  }

  // Salvar em S3
  try {
    const { url } = await storagePut(
      `generated/${Date.now()}.png`,
      buffer,
      mimeType
    );
    return { url };
  } catch (e) {
    console.error("[imageGeneration] Failed to save to storage:", e);
    throw new Error(`Failed to save generated image to storage: ${String(e)}`);
  }
}
