/**
 * Sistema de cache em memória com TTL
 */
export class CacheManager {
  private cache: Map<
    string,
    { value: any; expiresAt: number; hits: number }
  > = new Map();
  private maxSize: number = 1000;
  private defaultTTL: number = 3600000; // 1 hora

  set(key: string, value: any, ttl: number = this.defaultTTL) {
    // Remove oldest entry if cache is full
    if (this.cache.size >= this.maxSize) {
      const oldestKey = Array.from(this.cache.entries()).sort(
        (a, b) => a[1].hits - b[1].hits
      )[0]?.[0];
      if (oldestKey) {
        this.cache.delete(oldestKey);
      }
    }

    this.cache.set(key, {
      value,
      expiresAt: Date.now() + ttl,
      hits: 0,
    });
  }

  get(key: string): any | null {
    const entry = this.cache.get(key);

    if (!entry) {
      return null;
    }

    // Check if expired
    if (entry.expiresAt < Date.now()) {
      this.cache.delete(key);
      return null;
    }

    // Increment hit count
    entry.hits++;
    return entry.value;
  }

  has(key: string): boolean {
    const entry = this.cache.get(key);
    return entry ? entry.expiresAt > Date.now() : false;
  }

  delete(key: string) {
    this.cache.delete(key);
  }

  clear() {
    this.cache.clear();
  }

  getStats() {
    return {
      size: this.cache.size,
      maxSize: this.maxSize,
      entries: Array.from(this.cache.entries()).map(([key, value]) => ({
        key,
        hits: value.hits,
        expiresIn: Math.max(0, value.expiresAt - Date.now()),
      })),
    };
  }
}

/**
 * Cache global para respostas similares
 */
export const globalCache = new CacheManager();

/**
 * Gerar hash para questão (para busca de cache)
 */
export function hashQuestion(question: string): string {
  return Buffer.from(question.toLowerCase().trim()).toString("base64");
}

/**
 * Busca semântica simples (baseada em similaridade de strings)
 */
export function calculateSimilarity(str1: string, str2: string): number {
  const s1 = str1.toLowerCase().trim();
  const s2 = str2.toLowerCase().trim();

  if (s1 === s2) return 1;

  const longer = s1.length > s2.length ? s1 : s2;
  const shorter = s1.length > s2.length ? s2 : s1;

  if (longer.length === 0) return 1;

  const editDistance = getEditDistance(longer, shorter);
  return (longer.length - editDistance) / longer.length;
}

/**
 * Calcular distância de edição (Levenshtein)
 */
function getEditDistance(s1: string, s2: string): number {
  const costs: number[] = [];

  for (let i = 0; i <= s1.length; i++) {
    let lastValue = i;
    for (let j = 0; j <= s2.length; j++) {
      if (i === 0) {
        costs[j] = j;
      } else if (j > 0) {
        let newValue = costs[j - 1];
        if (s1.charAt(i - 1) !== s2.charAt(j - 1)) {
          newValue = Math.min(Math.min(newValue, lastValue), costs[j]) + 1;
        }
        costs[j - 1] = lastValue;
        lastValue = newValue;
      }
    }
    if (i > 0) {
      costs[s2.length] = lastValue;
    }
  }

  return costs[s2.length];
}

/**
 * Encontrar respostas em cache similares
 */
export function findSimilarCachedResponse(
  question: string,
  threshold: number = 0.8
): any | null {
  const stats = globalCache.getStats();

  for (const entry of stats.entries) {
    const similarity = calculateSimilarity(question, entry.key);
    if (similarity >= threshold) {
      const cached = globalCache.get(entry.key);
      if (cached) {
        return {
          response: cached,
          similarity,
        };
      }
    }
  }

  return null;
}

/**
 * Resumir texto longo (simples)
 */
export function summarizeText(text: string, maxLength: number = 200): string {
  if (text.length <= maxLength) {
    return text;
  }

  // Encontrar última frase completa dentro do limite
  const truncated = text.substring(0, maxLength);
  const lastPeriod = truncated.lastIndexOf(".");

  if (lastPeriod > 0) {
    return truncated.substring(0, lastPeriod + 1) + "...";
  }

  return truncated + "...";
}

/**
 * Detectar intenção do usuário (simples)
 */
export function detectUserIntent(
  message: string
): "question" | "statement" | "command" | "greeting" {
  const lower = message.toLowerCase().trim();

  if (
    lower.endsWith("?") ||
    lower.startsWith("o que") ||
    lower.startsWith("como") ||
    lower.startsWith("por que") ||
    lower.startsWith("quando") ||
    lower.startsWith("onde") ||
    lower.startsWith("quem")
  ) {
    return "question";
  }

  if (
    lower.startsWith("/") ||
    lower.startsWith("!") ||
    lower.includes("execute") ||
    lower.includes("faça")
  ) {
    return "command";
  }

  if (
    lower.includes("oi") ||
    lower.includes("olá") ||
    lower.includes("opa") ||
    lower.includes("e aí")
  ) {
    return "greeting";
  }

  return "statement";
}

/**
 * Análise de sentimento simples
 */
export function analyzeSentiment(
  text: string
): "positive" | "negative" | "neutral" {
  const lower = text.toLowerCase();

  const positiveWords = [
    "bom",
    "ótimo",
    "excelente",
    "adorei",
    "amei",
    "perfeito",
    "incrível",
    "maravilhoso",
    "feliz",
    "alegre",
  ];
  const negativeWords = [
    "ruim",
    "péssimo",
    "horrível",
    "odeio",
    "detesto",
    "terrível",
    "chato",
    "triste",
    "raiva",
    "frustrado",
  ];

  let positiveCount = 0;
  let negativeCount = 0;

  for (const word of positiveWords) {
    if (lower.includes(word)) positiveCount++;
  }

  for (const word of negativeWords) {
    if (lower.includes(word)) negativeCount++;
  }

  if (positiveCount > negativeCount) {
    return "positive";
  } else if (negativeCount > positiveCount) {
    return "negative";
  }

  return "neutral";
}
