import { eq, and, desc, asc, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, conversations, messages, fileUploads, userPreferences, InsertUserPreferences, UserPreferences } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

/**
 * Conversation queries
 */
export async function getUserConversations(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(conversations).where(eq(conversations.userId, userId)).orderBy(desc(conversations.updatedAt));
}

export async function getConversation(conversationId: number, userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(conversations).where(
    and(eq(conversations.id, conversationId), eq(conversations.userId, userId))
  ).limit(1);
  return result[0];
}

export async function createConversation(userId: number, title: string = "Nova Conversa") {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  // Insert a new conversation
  await db.insert(conversations).values({ userId, title });
  
  // Fetch the newly created conversation
  const result = await db.select().from(conversations)
    .where(eq(conversations.userId, userId))
    .orderBy(desc(conversations.id))
    .limit(1);
  
  if (!result[0]) {
    throw new Error("Failed to create conversation");
  }
  
  return result[0];
}

export async function updateConversationTitle(conversationId: number, userId: number, title: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.update(conversations).set({ title, updatedAt: new Date() }).where(
    and(eq(conversations.id, conversationId), eq(conversations.userId, userId))
  );
}

export async function deleteConversation(conversationId: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  // Delete associated messages first
  await db.delete(messages).where(eq(messages.conversationId, conversationId));
  // Then delete the conversation
  return db.delete(conversations).where(
    and(eq(conversations.id, conversationId), eq(conversations.userId, userId))
  );
}

/**
 * Message queries
 */
export async function getConversationMessages(conversationId: number, limit: number = 100, offset: number = 0) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(messages)
    .where(eq(messages.conversationId, conversationId))
    .orderBy(asc(messages.createdAt))
    .limit(limit)
    .offset(offset);
}

export async function getConversationMessagesCount(conversationId: number) {
  const db = await getDb();
  if (!db) return 0;
  const result = await db.select({ count: sql`COUNT(*)` }).from(messages).where(eq(messages.conversationId, conversationId));
  return result[0]?.count || 0;
}

export async function addMessage(
  conversationId: number,
  role: "user" | "assistant",
  content: string,
  attachments?: Array<{ type: string; url: string; name: string; mimeType?: string }>
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(messages).values({
    conversationId,
    role,
    content,
    attachments: attachments || undefined,
  });
}

/**
 * File upload queries
 */
export async function saveFileUpload(
  userId: number,
  conversationId: number | null,
  fileName: string,
  fileKey: string,
  fileUrl: string,
  mimeType: string,
  fileSize: number
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(fileUploads).values({
    userId,
    conversationId,
    fileName,
    fileKey,
    fileUrl,
    mimeType,
    fileSize,
  });
}

/**
 * User preferences queries
 */
export async function getUserPreferences(userId: number): Promise<UserPreferences | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(userPreferences).where(eq(userPreferences.userId, userId)).limit(1);
  return result[0];
}

export async function createOrUpdateUserPreferences(userId: number, preferences: Partial<InsertUserPreferences>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const existing = await getUserPreferences(userId);
  
  if (existing) {
    // Update existing preferences
    return db.update(userPreferences).set({
      ...preferences,
      updatedAt: new Date(),
    }).where(eq(userPreferences.userId, userId));
  } else {
    // Create new preferences
    return db.insert(userPreferences).values({
      userId,
      ...preferences,
    });
  }
}
