/**
 * Configuração de múltiplos modelos de IA
 */

export interface ModelConfig {
  id: string;
  name: string;
  provider: "openai" | "anthropic" | "local";
  maxTokens: number;
  costPer1kTokens: number;
  avgResponseTime: number; // ms
  description: string;
  capabilities: string[];
  enabled: boolean;
}

export const AVAILABLE_MODELS: Record<string, ModelConfig> = {
  "gpt-4": {
    id: "gpt-4",
    name: "GPT-4",
    provider: "openai",
    maxTokens: 8192,
    costPer1kTokens: 0.03,
    avgResponseTime: 2000,
    description: "Modelo mais avançado da OpenAI com melhor compreensão",
    capabilities: [
      "reasoning",
      "code",
      "analysis",
      "creative",
      "multilingual",
    ],
    enabled: true,
  },
  "gpt-3.5-turbo": {
    id: "gpt-3.5-turbo",
    name: "GPT-3.5 Turbo",
    provider: "openai",
    maxTokens: 4096,
    costPer1kTokens: 0.002,
    avgResponseTime: 500,
    description: "Modelo rápido e econômico da OpenAI",
    capabilities: ["code", "analysis", "creative", "multilingual"],
    enabled: true,
  },
  "claude-3-opus": {
    id: "claude-3-opus",
    name: "Claude 3 Opus",
    provider: "anthropic",
    maxTokens: 200000,
    costPer1kTokens: 0.015,
    avgResponseTime: 1500,
    description: "Modelo mais poderoso do Claude com contexto grande",
    capabilities: [
      "reasoning",
      "code",
      "analysis",
      "creative",
      "multilingual",
      "long-context",
    ],
    enabled: true,
  },
  "claude-3-sonnet": {
    id: "claude-3-sonnet",
    name: "Claude 3 Sonnet",
    provider: "anthropic",
    maxTokens: 200000,
    costPer1kTokens: 0.003,
    avgResponseTime: 800,
    description: "Modelo balanceado do Claude",
    capabilities: ["code", "analysis", "creative", "multilingual"],
    enabled: true,
  },
  "llama-2-70b": {
    id: "llama-2-70b",
    name: "Llama 2 70B",
    provider: "local",
    maxTokens: 4096,
    costPer1kTokens: 0.0,
    avgResponseTime: 3000,
    description: "Modelo open-source poderoso (local)",
    capabilities: ["code", "analysis", "creative", "multilingual"],
    enabled: false,
  },
};

export interface ModelSettings {
  modelId: string;
  temperature: number; // 0-2
  topP: number; // 0-1
  topK: number; // 0-100
  frequencyPenalty: number; // -2 to 2
  presencePenalty: number; // -2 to 2
  maxTokens: number;
}

export const DEFAULT_MODEL_SETTINGS: ModelSettings = {
  modelId: "gpt-4",
  temperature: 0.7,
  topP: 0.9,
  topK: 40,
  frequencyPenalty: 0,
  presencePenalty: 0,
  maxTokens: 2048,
};

/**
 * Selecionar modelo baseado em critérios
 */
export function selectModelByCapability(
  capability: string
): ModelConfig | null {
  const models = Object.values(AVAILABLE_MODELS).filter(
    (m) => m.enabled && m.capabilities.includes(capability)
  );

  // Ordenar por custo (mais barato primeiro)
  return models.sort((a, b) => a.costPer1kTokens - b.costPer1kTokens)[0] || null;
}

/**
 * Selecionar modelo mais rápido
 */
export function selectFastestModel(): ModelConfig | null {
  const models = Object.values(AVAILABLE_MODELS).filter((m) => m.enabled);
  return models.sort((a, b) => a.avgResponseTime - b.avgResponseTime)[0] || null;
}

/**
 * Selecionar modelo mais econômico
 */
export function selectCheapestModel(): ModelConfig | null {
  const models = Object.values(AVAILABLE_MODELS).filter((m) => m.enabled);
  return models.sort((a, b) => a.costPer1kTokens - b.costPer1kTokens)[0] || null;
}

/**
 * Calcular custo estimado
 */
export function estimateCost(
  modelId: string,
  inputTokens: number,
  outputTokens: number
): number {
  const model = AVAILABLE_MODELS[modelId];
  if (!model) return 0;

  const inputCost = (inputTokens / 1000) * model.costPer1kTokens;
  const outputCost = (outputTokens / 1000) * model.costPer1kTokens;

  return inputCost + outputCost;
}

/**
 * Validar configurações de modelo
 */
export function validateModelSettings(settings: ModelSettings): string[] {
  const errors: string[] = [];

  if (!AVAILABLE_MODELS[settings.modelId]) {
    errors.push(`Modelo ${settings.modelId} não existe`);
  }

  if (settings.temperature < 0 || settings.temperature > 2) {
    errors.push("Temperature deve estar entre 0 e 2");
  }

  if (settings.topP < 0 || settings.topP > 1) {
    errors.push("Top P deve estar entre 0 e 1");
  }

  if (settings.topK < 0 || settings.topK > 100) {
    errors.push("Top K deve estar entre 0 e 100");
  }

  if (settings.maxTokens < 1 || settings.maxTokens > 32000) {
    errors.push("Max tokens deve estar entre 1 e 32000");
  }

  return errors;
}

/**
 * Obter recomendação de modelo baseada em tipo de tarefa
 */
export function recommendModelForTask(
  taskType:
    | "analysis"
    | "coding"
    | "creative"
    | "reasoning"
    | "fast"
    | "cheap"
): ModelConfig | null {
  switch (taskType) {
    case "analysis":
      return selectModelByCapability("analysis");
    case "coding":
      return selectModelByCapability("code");
    case "creative":
      return selectModelByCapability("creative");
    case "reasoning":
      return selectModelByCapability("reasoning");
    case "fast":
      return selectFastestModel();
    case "cheap":
      return selectCheapestModel();
    default:
      return AVAILABLE_MODELS["gpt-4"] || null;
  }
}
