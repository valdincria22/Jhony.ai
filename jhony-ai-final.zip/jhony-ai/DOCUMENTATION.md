# IA Jhony - Documentação Completa

## 📋 Visão Geral

**IA Jhony** é uma plataforma profissional de inteligência artificial no nível do Manus.ia, com funcionalidades avançadas para chat, webhooks, análise de contexto e suporte a múltiplos modelos de IA.

## 🎯 Funcionalidades Principais

### 1. Interface de Chat Premium
- Chat interativo com histórico persistente
- Renderização de markdown com Streamdown
- Suporte a Enter/Shift+Enter
- Animações suaves (fade-in, slide)
- Tema escuro imersivo com gradiente violeta-teal

### 2. Streaming de Respostas (SSE)
- Server-Sent Events para respostas em tempo real
- Atualização incremental de mensagens
- Cancelamento de requisições
- Indicador de progresso

**Endpoint:** `GET /api/stream/chat/:conversationId`

```bash
curl -N "http://localhost:3000/api/stream/chat/123"
```

### 3. Sistema de Webhooks
Receba dúvidas de múltiplas fontes e obtenha respostas automáticas.

#### Webhook Genérico
```bash
POST /api/webhooks/ask
Content-Type: application/json

{
  "question": "Como usar IA Jhony?",
  "source": "api",
  "returnUrl": "https://seu-site.com/callback",
  "userId": "user123"
}
```

#### WhatsApp
```bash
POST /api/webhooks/whatsapp
{
  "message": "Olá Jhony!",
  "phoneNumber": "+55 11 99999-9999"
}
```

#### Telegram
```bash
POST /api/webhooks/telegram
{
  "message": "Olá Jhony!",
  "chatId": "123456",
  "userId": "user123"
}
```

#### Discord
```bash
POST /api/webhooks/discord
{
  "message": "Olá Jhony!",
  "channelId": "channel123",
  "userId": "user123"
}
```

### 4. Upload de Arquivos
Suporte completo para PDF, imagens, documentos, áudio e vídeo.

**Tipos suportados:**
- PDF: `application/pdf`
- Imagens: `image/jpeg`, `image/png`, `image/webp`
- Áudio: `audio/mpeg`, `audio/wav`, `audio/mp4`
- Vídeo: `video/mp4`, `video/webm`
- Documentos: `text/plain`, `application/msword`

### 5. Geração de Imagens
Gere imagens via IA Jhony diretamente no chat.

```typescript
// No chat, use:
const response = await trpc.chat.generateImage.useMutation({
  prompt: "Uma paisagem montanhosa ao pôr do sol"
});
```

### 6. Transcrição de Áudio
Converta áudio em texto automaticamente.

```typescript
const response = await trpc.chat.transcribeAudio.useMutation({
  audioUrl: "https://storage.example.com/audio.mp3",
  language: "pt"
});
```

### 7. Tratamento Robusto de Erros
- UI de erro visível com detalhes
- Retry automático com backoff exponencial
- Fallback para modelos alternativos
- Logging estruturado

**Componente:**
```tsx
import { ErrorAlert, useErrorHandler } from "@/components/ErrorBoundaryUI";

const { error, handleError, retry } = useErrorHandler();

// Usar em UI
<ErrorAlert error={error} onRetry={() => retry(myAsyncFunction)} />
```

### 8. Paginação de Histórico
Carregue mensagens em páginas para melhor performance.

```typescript
import { usePaginatedMessages } from "@/components/MessagePagination";

const { messages, pagination, loadPage } = usePaginatedMessages(20);
```

### 9. Cache Inteligente
Sistema de cache com TTL e busca semântica.

```typescript
import { globalCache, findSimilarCachedResponse } from "@/server/cache";

// Armazenar resposta
globalCache.set("Como fazer café?", "Resposta...", 3600000);

// Buscar similar
const result = findSimilarCachedResponse("Como preparar café?", 0.8);
```

### 10. Análise de Contexto

#### Detecção de Intenção
```typescript
import { detectUserIntent } from "@/server/cache";

const intent = detectUserIntent("O que é IA?");
// Returns: "question" | "statement" | "command" | "greeting"
```

#### Análise de Sentimento
```typescript
import { analyzeSentiment } from "@/server/cache";

const sentiment = analyzeSentiment("Adorei! Excelente!");
// Returns: "positive" | "negative" | "neutral"
```

#### Resumo de Texto
```typescript
import { summarizeText } from "@/server/cache";

const summary = summarizeText(longText, 200);
```

### 11. Múltiplos Modelos de IA

#### Modelos Disponíveis
- **GPT-4**: Modelo mais avançado (8K tokens)
- **GPT-3.5 Turbo**: Rápido e econômico (4K tokens)
- **Claude 3 Opus**: Contexto grande (200K tokens)
- **Claude 3 Sonnet**: Balanceado (200K tokens)
- **Llama 2 70B**: Open-source (4K tokens)

#### Seleção de Modelo
```typescript
import {
  selectModelByCapability,
  selectFastestModel,
  selectCheapestModel,
  recommendModelForTask
} from "@/server/models";

// Por capacidade
const codeModel = selectModelByCapability("code");

// Mais rápido
const fastModel = selectFastestModel();

// Mais barato
const cheapModel = selectCheapestModel();

// Por tarefa
const model = recommendModelForTask("coding");
// "analysis" | "coding" | "creative" | "reasoning" | "fast" | "cheap"
```

#### Configurações Avançadas
```typescript
import { DEFAULT_MODEL_SETTINGS } from "@/server/models";

const settings = {
  modelId: "gpt-4",
  temperature: 0.7,    // 0-2 (criatividade)
  topP: 0.9,          // 0-1 (diversidade)
  topK: 40,           // 0-100 (variedade)
  frequencyPenalty: 0, // -2 a 2
  presencePenalty: 0,  // -2 a 2
  maxTokens: 2048
};
```

#### Estimativa de Custo
```typescript
import { estimateCost } from "@/server/models";

const cost = estimateCost("gpt-4", 1000, 500);
// Retorna: 0.0225 (USD)
```

## 🔌 Autenticação

### OAuth Manus
A plataforma usa OAuth Manus para autenticação segura.

```typescript
import { getLoginUrl } from "@/const";

// Redirecionar para login
window.location.href = getLoginUrl();
```

### Verificar Autenticação
```typescript
import { useAuth } from "@/_core/hooks/useAuth";

const { user, isAuthenticated, logout } = useAuth();
```

## 📊 Banco de Dados

### Tabelas
- **users**: Usuários autenticados
- **conversations**: Conversas do usuário
- **messages**: Mensagens nas conversas
- **attachments**: Arquivos enviados

### Schema
```typescript
// Conversas
{
  id: number;
  userId: number;
  title: string;
  createdAt: Date;
  updatedAt: Date;
}

// Mensagens
{
  id: number;
  conversationId: number;
  role: "user" | "assistant";
  content: string;
  attachments: JSON | null;
  createdAt: Date;
}

// Attachments
{
  id: number;
  messageId: number;
  fileName: string;
  fileKey: string;
  fileUrl: string;
  mimeType: string;
  fileSize: number;
  createdAt: Date;
}
```

## 🧪 Testes

### Executar Testes
```bash
pnpm test
```

### Cobertura de Testes
- ✅ 40 testes Vitest passando
- ✅ Autenticação e procedures tRPC
- ✅ Funcionalidades avançadas (cache, models, sentiment)
- ✅ Integração de chat
- ✅ Tratamento de erros

## 🚀 Deployment

### Build
```bash
pnpm build
```

### Start
```bash
pnpm start
```

### Variáveis de Ambiente
```env
DATABASE_URL=mysql://user:password@host/database
JWT_SECRET=seu-secret-aqui
VITE_APP_ID=seu-app-id
OAUTH_SERVER_URL=https://api.manus.im
VITE_OAUTH_PORTAL_URL=https://manus.im
VITE_FRONTEND_FORGE_API_URL=https://api.manus.im
VITE_FRONTEND_FORGE_API_KEY=seu-api-key
BUILT_IN_FORGE_API_URL=https://api.manus.im
BUILT_IN_FORGE_API_KEY=seu-api-key
```

## 📱 API Endpoints

### Chat
- `POST /api/trpc/chat.sendMessage` - Enviar mensagem
- `GET /api/trpc/chat.getConversation` - Obter conversa
- `GET /api/trpc/chat.getConversations` - Listar conversas
- `POST /api/trpc/chat.createConversation` - Criar conversa
- `POST /api/trpc/chat.updateConversationTitle` - Renomear
- `POST /api/trpc/chat.deleteConversation` - Deletar
- `POST /api/trpc/chat.uploadFile` - Upload de arquivo
- `POST /api/trpc/chat.generateImage` - Gerar imagem
- `POST /api/trpc/chat.transcribeAudio` - Transcrever áudio

### Webhooks
- `POST /api/webhooks/ask` - Webhook genérico
- `POST /api/webhooks/whatsapp` - WhatsApp
- `POST /api/webhooks/telegram` - Telegram
- `POST /api/webhooks/discord` - Discord

### Auth
- `GET /api/trpc/auth.me` - Usuário atual
- `POST /api/trpc/auth.logout` - Logout

## 🎨 Design

### Cores
- Gradiente: Violeta (#7C3AED) → Teal (#14B8A6)
- Texto: Branco (#FFFFFF)
- Fundo: Escuro (#0F172A)

### Tipografia
- Font: Sistema padrão (sans-serif)
- Tamanho: Bold e oversized
- Posicionamento: Assimétrico

### Animações
- `animate-fade-in`: Fade com translateY
- `animate-slide-in-left`: Slide da esquerda
- `animate-slide-in-right`: Slide da direita
- `animate-pulse-glow`: Pulso com opacidade

## 📚 Recursos Adicionais

### Componentes Principais
- `ChatBox.tsx`: Interface de chat
- `Sidebar.tsx`: Navegação de conversas
- `ErrorBoundaryUI.tsx`: Tratamento de erros
- `MessagePagination.tsx`: Paginação
- `ImageGeneratorButton.tsx`: Geração de imagens
- `AudioRecorder.tsx`: Transcrição de áudio

### Utilitários
- `server/streaming.ts`: SSE e streaming
- `server/webhooks.ts`: Integração de webhooks
- `server/cache.ts`: Cache e análise
- `server/models.ts`: Gerenciamento de modelos

## 🤝 Suporte

Para dúvidas ou problemas, entre em contato através dos webhooks ou use o chat direto na plataforma.

---

**IA Jhony** - Inteligência Artificial Profissional sem Restrições
