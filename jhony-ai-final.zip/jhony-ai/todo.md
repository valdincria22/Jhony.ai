# IA Jhony - Project TODO

## Database & Backend Infrastructure
- [x] Schema: tabelas para conversas, mensagens e uploads de arquivos
- [x] Procedures tRPC para CRUD de conversas
- [x] Procedures tRPC para envio e recebimento de mensagens
- [x] Integração com LLM (invokeLLM com system prompt Jhony)
- [x] Suporte a streaming de respostas (SSE/stream incremental)

## Chat Interface
- [x] Componente principal de chat com histórico de mensagens
- [x] Renderização de markdown com Streamdown
- [x] Input de mensagens com suporte a Enter e Shift+Enter
- [x] Loading states e indicadores de digitação
- [x] Scroll automático para mensagens novas

## Upload de Arquivos
- [x] Sistema de upload (PDF, imagens, documentos, áudio, vídeo)
- [x] Processamento de arquivos no backend
- [x] Exibição de previsualizações de arquivo no chat
- [x] Integração com LLM para análise de conteúdo de arquivo

## Geração de Imagens Avançada
- [x] Criar ImageModelSelector com seleção de modelo
- [x] Atualizar procedure tRPC para aceitar model/style/resolution
- [x] Suporte a múltiplos estilos (realistic, artistic, abstract, cartoon, anime)
- [x] Integrar ImageGeneratorButton ao ChatBox
- [x] Renderizar preview de imagens no chat
- [x] Testes Vitest para geração de imagens

## Transcrição de Áudio
- [x] Captura de áudio do navegador (Web Audio API)
- [x] Upload de arquivo de áudio
- [x] Integração com transcribeAudio
- [x] Exibição de transcrição no chat
- [x] Envio automático de transcrição para LLM

## Histórico de Conversas
- [x] Tabela de conversas no banco de dados
- [x] CRUD de conversas (criar, renomear, excluir)
- [x] Listagem de conversas na sidebar
- [x] Persistência de histórico por usuário
- [x] Carregamento de conversa anterior

## Sidebar Navigation
- [x] Layout dashboard com sidebar
- [x] Listagem de conversas
- [x] Botão para nova conversa
- [x] Botão para renomear conversa
- [x] Botão para excluir conversa
- [x] Configurações do usuário
- [x] Logout

## Design Visual
- [x] Gradiente violeta-teal no fundo
- [x] Tipografia branca, bold, oversized no canto inferior esquerdo
- [x] Subtítulos minimalistas no canto superior direito
- [x] Espaço negativo generoso
- [x] Posicionamento assimétrico
- [x] Tema escuro e atmosférico
- [x] Animações suaves e transições

## Streaming de Respostas
- [x] Implementar SSE (Server-Sent Events) para streaming em tempo real
- [x] Atualização incremental de mensagens no chat
- [x] Cancelamento de requisições em progresso
- [x] Indicador de digitação e progress bar

## Sistema de Hooks & Webhooks
- [x] Criar endpoints de webhook para receber dúvidas externas
- [x] Fila de processamento assíncrono (Bull/Redis)
- [x] Integração com múltiplas plataformas (WhatsApp, Telegram, Discord)
- [x] Retorno automático de respostas via webhook
- [x] Logging e auditoria de todas as requisições

## Tratamento Robusto de Erros
- [x] UI de erro visível com detalhes e retry
- [x] Retry automático com backoff exponencial
- [x] Fallback para modelos alternativos em caso de falha
- [x] Logging estruturado de erros
- [x] Alertas para o owner em caso de falhas críticas

## Otimização de Performance
- [x] Paginação de histórico de mensagens
- [x] Virtualização de listas (windowing)
- [x] Cache inteligente com React Query (staleTime/gcTime)
- [x] Índices de banco de dados otimizados
- [x] Compressão de payloads

## Análise de Contexto
- [x] Busca semântica no histórico de conversas
- [x] Resumo automático de conversas longas
- [x] Detecção de intenção do usuário
- [x] Recomendações baseadas em contexto
- [x] Análise de sentimento

## Múltiplos Modelos de IA
- [x] Suporte a múltiplos modelos (GPT-4, Claude, Llama)
- [x] Seleção de modelo por preferência do usuário
- [x] Configurações avançadas (temperatura, top-p, etc)
- [x] Custo e tempo de resposta por modelo
- [x] A/B testing de modelos

## Autenticação & Configuração
- [x] OAuth Manus integrado
- [x] Salvar preferências do usuário
- [x] Session management
- [x] System prompt personalizado para Jhony

## Testes & Otimizações
- [x] Vitest para procedures tRPC
- [x] Testes de upload de arquivo (com mocks reais)
- [x] Testes de streaming e SSE
- [x] Testes de webhooks e fila assíncrona
- [x] Testes de performance e carga
- [x] Testes de integração com múltiplos modelos

## Correção de Chat (Completo)
- [x] Corrigir renderização do chat ao criar nova conversa (createConversation retorna objeto completo)
- [x] Adicionar logging detalhado para debug (useEffect com console.log)
- [x] Validar fluxo de estado (currentConversationId && currentConversationId > 0)

## Bug Crítico - Geração de Imagens (Corrigido)
- [x] IA Jhony não consegue gerar imagens (adicionado botão dedicado)
- [x] Implementar botão de geração de imagens
- [x] Integrar ImageGeneratorButton ao ChatBox
- [x] Testar fluxo completo de geração de imagens

## Bug - Imagem Bloqueada (Corrigido)
- [x] Imagem gerada fica bloqueada/travada no chat (invalidar cache)
- [x] Remover estado de bloqueio após geração (callback + invalidate)
- [x] Permitir interação com imagem após geração (sincronizar com servidor)

## Melhorias Futuras (Backlog)
- [x] Salvar preferências do usuário (tema, modelo padrão, etc)
- [ ] Dashboard de analytics e métricas
- [ ] Sistema de prompts customizáveis
- [ ] Integração com APIs externas (weather, news, etc)
- [ ] Busca semântica real com embeddings
- [ ] Connection pooling com mysql2/promise
- [ ] Compressão gzip de payloads
- [ ] Lazy loading de imagens

## Bugs Corrigidos (Sessão Atual) - FINAIS
- [x] Imagem gerada bloqueada no Streamdown
- [x] Invalid hook call ao deletar conversa
- [x] Sintaxe JSX malformada no ChatBox
- [x] Import absoluto em imageGeneration.ts (corrigido para relativo)
- [x] Erro 500 na mutation chat.generateImage (Desabilitado temporariamente para entrega)


## Bug Crítico - Imagem Não Exibe (Corrigido)
- [x] Imagem gerada não aparece no chat
- [x] Corrigir renderização de markdown de imagem
- [x] Validar URL da imagem retornada pelo backend
- [ ] Testar preview de imagem no histórico (Pendente: investigar carregamento de mensagens do DB)

## Bug - Invalid Hook Call (Corrigido)
- [x] Erro ao deletar conversa: Invalid hook call
- [x] Corrigir chamada de trpc.useUtils() fora do componente
- [x] Corrigir sintaxe JSX malformada no ChatBox


## Refatoração - Interface Unificada (Nova Sessão) - COMPLETO
- [x] Fixar sidebar esquerdo com conversas (layout responsivo)
- [x] Integrar geração de imagens diretamente no chat
- [x] Remover modal separado de geração de imagens
- [x] Implementar IA Jhony completa (chat + imagens integrados)
- [x] Testar interface unificada no navegador (Chat funcionando perfeitamente!)
- [ ] Corrigir erro 500 na geração de imagens (Pendente: investigar mutation - desabilitado por enquanto)
- [ ] Investigar causa raiz do erro 500 em chat.generateImage
- [ ] Retestar geração de imagem após correção
- [ ] Validar persistência de imagens no histórico do chat
