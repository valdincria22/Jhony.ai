# Análise do Problema de Geração de Imagem

## Problema Observado
- Mensagem aparece no topo: "[Image blocked: Generated Image]"
- A imagem não está sendo renderizada no chat
- O markdown `![Generated Image](url)` não está sendo processado corretamente

## Causas Possíveis

1. **Markdown não está sendo renderizado corretamente**
   - Streamdown pode não estar processando imagens markdown
   - CSS pode estar bloqueando imagens

2. **URL da imagem pode estar incorreta**
   - `/manus-storage/...` pode não estar acessível
   - Proxy de armazenamento pode estar falhando

3. **Problema de integração do ImageGeneratorButton**
   - Callback pode não estar sendo chamado
   - Mensagem pode não estar sendo adicionada ao histórico

## Próximos Passos

1. Verificar se Streamdown renderiza imagens markdown
2. Testar URL da imagem diretamente no navegador
3. Adicionar logging para debug de callback
4. Verificar se há erro de CORS ou proxy
