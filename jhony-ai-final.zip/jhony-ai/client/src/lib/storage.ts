export async function storagePut(
  key: string,
  data: Uint8Array | Buffer | string,
  contentType?: string
): Promise<{ key: string; url: string }> {
  try {
    const apiUrl = import.meta.env.VITE_FRONTEND_FORGE_API_URL || '';
    const apiKey = import.meta.env.VITE_FRONTEND_FORGE_API_KEY || '';
    
    const response = await fetch(`${apiUrl}/storage/put`, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        key,
        data: typeof data === "string" ? data : Buffer.from(data).toString("base64"),
        contentType,
      }),
    });

    if (!response.ok) {
      throw new Error(`Storage error: ${response.statusText}`);
    }

    const result = await response.json();
    return {
      key: result.key,
      url: result.url || `/manus-storage/${result.key}`,
    };
  } catch (error) {
    console.error("Error uploading to storage:", error);
    throw error;
  }
}

export async function storageGet(key: string, expiresIn?: number): Promise<string> {
  try {
    const apiUrl = import.meta.env.VITE_FRONTEND_FORGE_API_URL || '';
    const apiKey = import.meta.env.VITE_FRONTEND_FORGE_API_KEY || '';
    
    const response = await fetch(`${apiUrl}/storage/get`, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        key,
        expiresIn,
      }),
    });

    if (!response.ok) {
      throw new Error(`Storage error: ${response.statusText}`);
    }

    const result = await response.json();
    return result.url;
  } catch (error) {
    console.error("Error getting from storage:", error);
    throw error;
  }
}
