import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Wand2, Loader2 } from "lucide-react";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

interface ImageGeneratorButtonProps {
  onImageGenerated?: (imageUrl: string) => void;
}

export function ImageGeneratorButton({
  onImageGenerated,
}: ImageGeneratorButtonProps) {
  const [open, setOpen] = useState(false);
  const [prompt, setPrompt] = useState("");

  const generateImageMutation = trpc.chat.generateImage.useMutation({
    onSuccess: (data) => {
      console.log('Image generation success:', data);
      if (data.imageUrl) {
        console.log('Image URL:', data.imageUrl);
        onImageGenerated?.(data.imageUrl);
        setPrompt("");
        setOpen(false);
      } else {
        console.error('No imageUrl in response:', data);
      }
    },
    onError: (error) => {
      console.error('Image generation error:', error);
    },
  });

  const handleGenerateImage = async () => {
    if (!prompt.trim()) return;
    await generateImageMutation.mutateAsync({ prompt });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="icon" title="Gerar Imagem">
          <Wand2 className="w-4 h-4" />
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Gerar Imagem</DialogTitle>
          <DialogDescription>
            Descreva a imagem que deseja gerar e a IA Jhony criará para você.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <Input
            placeholder="Ex: Uma paisagem montanhosa ao pôr do sol..."
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !generateImageMutation.isPending) {
                handleGenerateImage();
              }
            }}
            disabled={generateImageMutation.isPending}
          />
          <Button
            onClick={handleGenerateImage}
            disabled={generateImageMutation.isPending || !prompt.trim()}
            className="w-full"
          >
            {generateImageMutation.isPending ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Gerando...
              </>
            ) : (
              <>
                <Wand2 className="w-4 h-4 mr-2" />
                Gerar Imagem
              </>
            )}
          </Button>
          {generateImageMutation.error && (
            <p className="text-sm text-destructive">
              Erro ao gerar imagem: {generateImageMutation.error.message}
            </p>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
