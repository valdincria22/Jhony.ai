import { useState, useRef, useEffect } from "react";
import { Streamdown } from "streamdown";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Loader2, Send, Wand2 } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { useStreamingChat } from "@/hooks/useStreamingChat";
import { useAuth } from "@/_core/hooks/useAuth";
import type { Message } from "@shared/types";
import { AudioRecorder } from "./AudioRecorder";
import { toast } from "sonner";

interface ChatBoxProps {
  conversationId: number;
  onNewConversation?: () => void;
}

// Componente para renderizar imagem com tratamento de erro
function ImageMessage({ imageUrl: rawImageUrl }: { imageUrl: string }) {
  const [imageError, setImageError] = useState(false);
  const [imageLoaded, setImageLoaded] = useState(false);

  // Normalizar URL para absoluta se for relativa
  let imageUrl = rawImageUrl;
  if (!imageUrl.startsWith("http")) {
    try {
      imageUrl = new URL(imageUrl, window.location.origin).toString();
    } catch (e) {
      console.error("Invalid image URL:", rawImageUrl);
      setImageError(true);
      return null;
    }
  }

  if (imageError) {
    return (
      <div className="mb-3 p-3 bg-red-500/20 border border-red-500/50 rounded-lg text-sm text-red-300">
        ⚠️ Erro ao carregar imagem
      </div>
    );
  }

  return (
    <div className="mb-3">
      <img
        src={imageUrl}
        alt="Generated Image"
        className="rounded-lg max-w-full h-auto"
        onLoad={() => setImageLoaded(true)}
        onError={(e) => {
          console.error("Image failed to load:", imageUrl);
          setImageError(true);
        }}
        style={{ opacity: imageLoaded ? 1 : 0.7 }}
      />
    </div>
  );
}

export function ChatBox({ conversationId, onNewConversation }: ChatBoxProps) {
  const [input, setInput] = useState("");
  const [streamingMessage, setStreamingMessage] = useState("");
  const [displayMessages, setDisplayMessages] = useState<Message[]>([]);
  const [isGeneratingImage, setIsGeneratingImage] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const utils = trpc.useUtils();
  const { user } = useAuth();

  const { data: conversationData, isLoading: isLoadingConversation } =
    trpc.chat.getConversation.useQuery(
      { conversationId },
      {
        staleTime: 1000 * 60 * 5,
        gcTime: 1000 * 60 * 10,
      }
    );

  const { isStreaming, sendMessageWithStream } = useStreamingChat();

  const generateImageMutation = trpc.chat.generateImage.useMutation({
    onSuccess: (data) => {
      if (data.imageUrl) {
        setDisplayMessages((prev) => [
          ...prev,
          {
            role: "assistant",
            content: `![Generated Image](${data.imageUrl})`,
            createdAt: new Date(),
          } as Message,
        ]);
        utils.chat.getConversation.invalidate({ conversationId });
        toast.success("Imagem gerada com sucesso!");
      }
    },
    onError: (error) => {
      toast.error("Erro ao gerar imagem");
      console.error("Image generation error:", error);
    },
  });

  // Atualizar mensagens quando conversa mudar
  useEffect(() => {
    if (conversationData?.messages) {
      setDisplayMessages(conversationData.messages);
      setStreamingMessage("");
    }
  }, [conversationData?.messages]);

  // Auto-scroll para última mensagem
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [displayMessages.length, streamingMessage]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isStreaming || !user) return;

    const userMessage = input;
    setInput("");

    // Adicionar mensagem do usuário imediatamente
    setDisplayMessages((prev) => [
      ...prev,
      {
        role: "user",
        content: userMessage,
        createdAt: new Date(),
      } as Message,
    ]);

    try {
      await sendMessageWithStream(
        conversationId,
        userMessage,
        user.id,
        (chunk) => {
          // Atualizar mensagem em streaming
          setStreamingMessage((prev) => prev + chunk.chunk + " ");
        },
        (fullResponse) => {
          // Adicionar resposta completa
          setDisplayMessages((prev) => [
            ...prev,
            {
              role: "assistant",
              content: fullResponse,
              createdAt: new Date(),
            } as Message,
          ]);
          setStreamingMessage("");
          // Invalidar cache para sincronizar
          utils.chat.getConversation.invalidate({ conversationId });
        }
      );
    } catch (error) {
      console.error("Error sending message:", error);
      setStreamingMessage("");
    }
  };

  const handleGenerateImage = async () => {
    if (!input.trim()) {
      toast.error("Digite um prompt para gerar imagem");
      return;
    }

    setIsGeneratingImage(true);
    try {
      await generateImageMutation.mutateAsync({ prompt: input });
      setInput("");
    } finally {
      setIsGeneratingImage(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      const form = e.currentTarget.form;
      if (form) {
        form.dispatchEvent(new Event("submit", { bubbles: true }));
      }
    }
  };

  if (isLoadingConversation) {
    return (
      <div className="flex items-center justify-center h-full">
        <Loader2 className="animate-spin w-8 h-8 text-muted-foreground" />
      </div>
    );
  }

  const messages = displayMessages;

  return (
    <div className="flex flex-col h-full bg-background animate-fade-in">
      {/* Messages Area */}
      <ScrollArea className="flex-1 p-4">
        <div className="space-y-4">
          {messages.length === 0 && !streamingMessage ? (
            <div className="flex flex-col items-center justify-center h-full text-center py-12">
              <div className="text-4xl font-bold text-primary mb-2">Jhony</div>
              <p className="text-muted-foreground">
                Comece uma conversa com a IA Jhony
              </p>
            </div>
          ) : (
            <>
              {messages.map((msg, idx) => {
                // Detectar imagens markdown e extrair URL
                const imageMatch = msg.content.match(
                  /!\[Generated Image\]\(([^)]+)\)/
                );
                const imageUrl = imageMatch ? imageMatch[1] : null;
                const contentWithoutImage = imageMatch
                  ? msg.content.replace(/!\[Generated Image\]\(([^)]+)\)/, "").trim()
                  : msg.content;

                return (
                  <div
                    key={idx}
                    className={`flex ${
                      msg.role === "user" ? "justify-end" : "justify-start"
                    }`}
                  >
                    <div
                      className={`${
                        imageUrl ? "max-w-2xl" : "max-w-xs lg:max-w-md"
                      } px-4 py-2 rounded-lg animate-fade-in ${
                        msg.role === "user"
                          ? "bg-primary text-primary-foreground"
                          : "bg-muted text-muted-foreground"
                      }`}
                    >
                      {imageUrl && <ImageMessage imageUrl={imageUrl} />}
                      {contentWithoutImage && msg.role === "assistant" ? (
                        <div className="prose prose-sm dark:prose-invert max-w-none">
                          <Streamdown>{contentWithoutImage}</Streamdown>
                        </div>
                      ) : contentWithoutImage ? (
                        <Streamdown>{contentWithoutImage}</Streamdown>
                      ) : null}
                    </div>
                  </div>
                );
              })}

              {/* Streaming message */}
              {streamingMessage && (
                <div className="flex justify-start">
                  <div className="max-w-xs lg:max-w-md px-4 py-2 rounded-lg bg-muted text-muted-foreground">
                    <Streamdown>{streamingMessage}</Streamdown>
                    <span className="inline-block ml-1 animate-pulse">▌</span>
                  </div>
                </div>
              )}

              {isStreaming && !streamingMessage && (
                <div className="flex justify-start">
                  <div className="px-4 py-2 rounded-lg bg-muted">
                    <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" />
                  </div>
                </div>
              )}
            </>
          )}
          <div ref={scrollRef} />
        </div>
      </ScrollArea>

      {/* Input Area */}
      <div className="border-t p-4 space-y-2">
        <form onSubmit={handleSendMessage} className="flex gap-2">
          <div className="flex-1 relative">
            <Textarea
              ref={textareaRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Digite sua mensagem... (Shift+Enter para nova linha)"
              className="resize-none pr-12"
              rows={3}
              disabled={isStreaming || isGeneratingImage}
            />
            <Button
              type="button"
              variant="outline"
              size="icon"
              onClick={() => {
                if (input.trim()) {
                  handleGenerateImage();
                } else {
                  toast.error("Digite um prompt para gerar imagem");
                }
              }}
              disabled={isStreaming || !input.trim() || isGeneratingImage}
              className="h-10 w-10"
              title="Gerar imagem (Ctrl+I)"
            >
              {isGeneratingImage ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Wand2 className="w-4 h-4" />
              )}
            </Button>
          </div>
          <div className="flex flex-col gap-2">
            <Button
              type="submit"
              disabled={isStreaming || !input.trim() || isGeneratingImage}
              className="h-full"
            >
              <Send className="w-4 h-4" />
            </Button>
          </div>
        </form>
        <div className="flex gap-2">
          <AudioRecorder onTranscription={(text) => setInput(text)} />
        </div>
      </div>
    </div>
  );
}
